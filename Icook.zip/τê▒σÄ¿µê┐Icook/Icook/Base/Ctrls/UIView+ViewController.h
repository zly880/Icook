//
//  UIView+ViewController.h
//  03-响应者链
//
//  Created by kangkathy on 15/12/21.
//  Copyright © 2015年 kangkathy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewController)

- (UIViewController *)viewController;

@end
