//
//  BaseViewController.h
//  Icook
//
//  Created by Macx on 16/1/31.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@end
