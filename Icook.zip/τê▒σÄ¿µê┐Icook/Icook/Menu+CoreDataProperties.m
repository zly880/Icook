//
//  Menu+CoreDataProperties.m
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Menu+CoreDataProperties.h"

@implementation Menu (CoreDataProperties)

@dynamic name;
@dynamic suggest;
@dynamic synopsis;
@dynamic menu_means;
@dynamic menu_material;

@end
