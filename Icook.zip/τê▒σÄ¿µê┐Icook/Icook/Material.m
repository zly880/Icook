//
//  Material.m
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "Material.h"

@implementation Material

// Insert code here to add functionality to your managed object subclass

@end
