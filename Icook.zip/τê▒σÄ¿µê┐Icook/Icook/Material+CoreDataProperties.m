//
//  Material+CoreDataProperties.m
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Material+CoreDataProperties.h"

@implementation Material (CoreDataProperties)

@dynamic materialName;
@dynamic height;

@end
