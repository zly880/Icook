//
//  InfoEditorViewController.h
//  Icook
//
//  Created by martin on 2/22/16.
//  Copyright © 2016 zly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InfoEditorViewController : UIViewController

@end
