//
//  SettingTableViewController.h
//  Icook
//
//  Created by martin on 2/19/16.
//  Copyright © 2016 zly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingTableViewController : UITableViewController

@end
