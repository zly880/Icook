//
//  MineFunctionsButtonsView.m
//  Icook
//
//  Created by martin on 2/20/16.
//  Copyright © 2016 zly. All rights reserved.
//

#import "MineFunctionsButtonsView.h"

@implementation MineFunctionsButtonsView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
