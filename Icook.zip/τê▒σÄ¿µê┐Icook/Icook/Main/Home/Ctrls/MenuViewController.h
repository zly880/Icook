//
//  MenuViewController.h
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "BaseViewController.h"

@interface MenuViewController : BaseViewController
@property (nonatomic, strong)  NSManagedObjectContext *context;

@end
