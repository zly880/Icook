//
//  CreateMenuViewController.h
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "BaseViewController.h"
#import "CreateMenu.h"

@interface CreateMenuViewController : BaseViewController

@property (nonatomic, strong)CreateMenu *tableview;

@property (nonatomic, copy)NSString *name;

@end
