//
//  WriteViewController.h
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "BaseViewController.h"
typedef  void (^ResponseBlock)(NSString *);
@interface WriteViewController : BaseViewController
@property(nonatomic, copy)ResponseBlock block;

@end
