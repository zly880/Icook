//
//  WriteViewController.m
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "WriteViewController.h"

@interface WriteViewController ()
{
    UITextView *_text;
}
@end

@implementation WriteViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"简介";
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self createTextFiled];
    
    [self createBackButton];
    
}

- (void)createTextFiled
{
    _text = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    
    [self.view addSubview:_text];
    
    _text.textAlignment = NSTextAlignmentLeft;
    
    _text.font = [UIFont systemFontOfSize:16];
    
    [_text becomeFirstResponder];
}

- (void)createBackButton
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    button.frame = CGRectMake(0, 0, 20, 20);
    
    [button setImage:[UIImage imageNamed:@"backStretchBackgroundNormal"] forState:UIControlStateNormal];
    [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:button];
    
    self.navigationItem.leftBarButtonItem = item;
    
    UIButton *buttonRight = [UIButton buttonWithType:UIButtonTypeCustom];
    
    buttonRight.frame = CGRectMake(0, 0, 40, 40);
    
    [buttonRight setTitle:@"保存" forState:UIControlStateNormal];
    
    [buttonRight setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    
    buttonRight.tag = 185;
    
    [buttonRight addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *itemT = [[UIBarButtonItem alloc] initWithCustomView:buttonRight];
    
    self.navigationItem.rightBarButtonItem = itemT;
    
}

- (void)clickButton:(UIButton *)sender
{
    if (sender.tag == 185 && _text.text != nil) {
        if (self.block) {
            self.block(_text.text);
        }
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
