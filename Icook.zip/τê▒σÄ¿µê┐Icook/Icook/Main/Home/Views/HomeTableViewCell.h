//
//  HomeTableViewCell.h
//  Icook
//
//  Created by Macx on 16/2/1.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeModel.h"

@interface HomeTableViewCell : UITableViewCell

@property (nonatomic, copy)HomeModel *homeModel;



@end
