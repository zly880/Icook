//
//  EatingView.m
//  Icook
//
//  Created by Macx on 16/2/5.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "EatingView.h"

@implementation EatingView



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
