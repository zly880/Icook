//
//  EatingView.h
//  Icook
//
//  Created by Macx on 16/2/5.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EatingView : UIScrollView

@end
