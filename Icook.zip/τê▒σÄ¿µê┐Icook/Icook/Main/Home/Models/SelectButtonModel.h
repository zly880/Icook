//
//  SelectButtonModel.h
//  Icook
//
//  Created by Macx on 16/2/1.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSONModel.h"
@interface SelectButtonModel :JSONModel

@property (nonatomic , copy)NSString *name;
@property (nonatomic , copy)NSString *picurl;
@property (nonatomic , copy)NSString *url;


@end
