//
//  MateralModel.m
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "MateralModel.h"

@implementation MateralModel

@end
