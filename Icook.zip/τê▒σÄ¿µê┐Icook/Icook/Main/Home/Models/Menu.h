//
//  Menu.h
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Menu : NSObject

@property (nonatomic, copy)NSString *name;//菜名
@property (nonatomic, copy)NSString *suggest;//小贴士
@property (nonatomic, copy)NSString *synopsis;//简介


@end
