//
//  MateralModel.h
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MateralModel : NSObject

@property (nonatomic, copy)NSString *name;//食材名称
@property (nonatomic, copy)NSString *number;//食材数量


@end
