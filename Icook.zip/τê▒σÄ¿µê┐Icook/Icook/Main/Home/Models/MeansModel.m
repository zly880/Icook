//
//  MeansModel.m
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "MeansModel.h"

@implementation MeansModel

@end
