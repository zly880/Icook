//
//  Material.h
//  Icook
//
//  Created by Macx on 16/2/23.
//  Copyright © 2016年 zly. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Material : NSObject

@property (nonatomic, copy)NSString *name;
@property (nonatomic, copy)NSString *materialName;
@property (nonatomic, assign)NSInteger *number;
@end
