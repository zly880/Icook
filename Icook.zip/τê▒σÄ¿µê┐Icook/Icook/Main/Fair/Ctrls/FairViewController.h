//
//  FairViewController.h
//  Icook
//
//  Created by Macx on 16/2/3.
//  Copyright © 2016年 zly. All rights reserved.
//

#import "BaseViewController.h"

@interface FairViewController : BaseViewController

@property (nonatomic, strong)UIWebView *webView;
@end
