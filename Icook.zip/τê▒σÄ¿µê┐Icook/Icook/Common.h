//
//  Common.h
//  84班测试微博
//
//  Created by wenyuan on 1/11/16.
//  Copyright © 2016 george. All rights reserved.
//

#ifndef Common_h
#define Common_h

#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScreenWidth [UIScreen mainScreen].bounds.size.width

#import "UIImageView+WebCache.h"
#import "UIViewExt.h"


#endif /* Common_h */
